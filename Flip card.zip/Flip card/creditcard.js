function updateCardDetails() {
    // Get values from the form inputs
    const cardNumber = document.getElementById("card-number-input").value;
    const cardHolder = document.getElementById("card-holder-input").value;
    const validDate = document.getElementById("valid-date-input").value;
    const cvv = document.getElementById("cvv-input").value;
  
    // Update the card display with user input or default values
    document.getElementById("display-card-number").textContent = cardNumber || "8050 2030 3020 5040";
    document.getElementById("display-card-name").textContent = cardHolder || "Shichabo Nkuna";
    document.getElementById("display-valid-date").textContent = validDate || "05/28";
    document.getElementById("display-cvv").textContent = cvv || "005";
    document.getElementById("display-name-back").textContent = cardHolder || "Nkuna wa mavutani";
  }
  
  // Optional: Add validation before submission
  document.getElementById("card-form").addEventListener("submit", function (event) {
    const cardNumber = document.getElementById("card-number-input").value;
    const cardHolder = document.getElementById("card-holder-input").value;
    const validDate = document.getElementById("valid-date-input").value;
    const cvv = document.getElementById("cvv-input").value;
  
    if (!cardNumber || !cardHolder || !validDate || !cvv) {
      alert("Please complete all fields.");
      event.preventDefault();  // Prevent form submission if any field is empty
    } else {
      // You can proceed with further form submission or payment processing here
      alert("Payment successful!");
    }
  });
  