const nodemailer = require("nodemailer");

const sendEmail = async (mailDetails) => {
    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        auth: {
            user: "youremail@site.com",
            pass: "your-password",
        },
        tls: {
            rejectUnauthorized: false
        }
    });

    try {
        console.log("Sending your email...");
        await transporter.sendMail(mailDetails);
        console.log(`Email sent successfully to ${mailDetails.to}`);
    } catch (error) {
        console.log("Sorry, failed to send your email!");
    }
}

sendEmail({
    from: "eqfy uxyi pkan oewy",
    to: "shichabonkuna22@gmail.com",
    subject: "Test Email via NodeJS using Nodemailer",
    text: "Hi, there...This is a test email sent via NodeJS App using Nodemailer."
});





const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');

const app = express();

app.use(bodyParser.json());

app.post('/send-email', async (req, res) => {
    const { from, to, subject, text } = req.body;

    const transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        auth: {
            user: 'shichabonkuna22@gmail.com',
            pass: 'eqfy uxyi pkan oewy',
        },
        tls: {
            rejectUnauthorized: false
        }
    });

    try {
        await transporter.sendMail({
            from: from,
            to: to,
            subject: subject,
            text: text
        });
        res.status(200).send('Email sent successfully');
    } catch (error) {
        res.status(500).send('Failed to send email');
    }
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
